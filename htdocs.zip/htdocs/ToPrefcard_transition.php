<?php session_start(); 
$con = mysqli_connect("localhost","root","","test");
$ret = "SELECT * FROM `surgeons` WHERE 1";
$result = ($con->query($ret));
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row['surgeon'] == $_SESSION['surgeon']){
            $val = $row;
        }
    }
}
print_r($val);
?>