<?php session_start(); 
$con = mysqli_connect("localhost","root","","test");
$ret = "SELECT * FROM `surgeons` WHERE 1";
$result = ($con->query($ret));
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row['surgeon'] == $_SESSION['surgeon']){
            $val = $row;
        }
    }
}
$_SESSION['searchBool'] = null;
$_SESSION["NeedleBox"] = 0;
?>

<!--  This site was created in Webflow. https://www.webflow.com  --><!--  Last Published: Fri May 03 2024 01:22:52 GMT+0000 (Coordinated Universal Time)  -->
<html data-wf-page="662ff875402765eb893847f8" data-wf-site="6629b58137d7c761e37bacd0">
<head>
  <meta charset="utf-8">
  <title>pref card</title>
  <meta content="pref card" property="og:title">
  <meta content="pref card" property="twitter:title">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <meta content="Webflow" name="generator">
  <link href="jeyan_v0/whiteboard-gui-v0//css/normalize.css" rel="stylesheet" type="text/css">
  <link href="jeyan_v0/whiteboard-gui-v0//css/webflow.css" rel="stylesheet" type="text/css">
  <link href="jeyan_v0/whiteboard-gui-v0//css/medtrack-main-gui.webflow.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
  <script type="text/javascript">WebFont.load({  google: {    families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic"]  }});</script>
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="jeyan_v0/whiteboard-gui-v0//images/favicon.ico" rel="shortcut icon" type="image/x-icon">
  <link href="jeyan_v0/whiteboard-gui-v0//images/webclip.png" rel="apple-touch-icon">
</head>
<body class="body-5">
  <div class="gloves-edit-window">
    <div class="gloves-edit-window-bg">
      <div class="w-layout-blockcontainer gloves-edit-container w-container">
        <div class="w-layout-vflex">
          <div class="w-layout-hflex">
            <div class="w-layout-hflex gloves-top-bar">
              <div class="gloves-title">Gloves</div>
              <div class="gloveds-qty">QTY</div>
              <a data-w-id="56d869e0-6e18-650f-d77c-54603f5d3fe4" href="#" class="closing-exit-button w-button"><svg class="ikonik-3gin4" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-n7ohvh" d="M18 6.00006C17.8124 5.81259 17.5581 5.70728 17.293 5.70728C17.0278 5.70728 16.7735 5.81259 16.586 6.00006L12 10.5861L7.41397 6.00006C7.22644 5.81259 6.97213 5.70728 6.70697 5.70728C6.44181 5.70728 6.1875 5.81259 5.99997 6.00006C5.8125 6.18759 5.70718 6.4419 5.70718 6.70706C5.70718 6.97223 5.8125 7.22653 5.99997 7.41406L10.586 12.0001L5.99997 16.5861C5.8125 16.7736 5.70718 17.0279 5.70718 17.2931C5.70718 17.5582 5.8125 17.8125 5.99997 18.0001C6.1875 18.1875 6.44181 18.2928 6.70697 18.2928C6.97213 18.2928 7.22644 18.1875 7.41397 18.0001L12 13.4141L16.586 18.0001C16.7735 18.1875 17.0278 18.2928 17.293 18.2928C17.5581 18.2928 17.8124 18.1875 18 18.0001C18.1874 17.8125 18.2928 17.5582 18.2928 17.2931C18.2928 17.0279 18.1874 16.7736 18 16.5861L13.414 12.0001L18 7.41406C18.1874 7.22653 18.2928 6.97223 18.2928 6.70706C18.2928 6.4419 18.1874 6.18759 18 6.00006Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
            </div>
          </div>
          <div class="w-layout-hflex">
            <div class="w-form">
              <form id="email-form" name="email-form" data-name="Email Form" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="fa1a3e14-f127-7457-af43-31dc303b52b5"><label class="w-checkbox piat-item-1">
                  <div class="w-checkbox-input w-checkbox-input--inputType-custom gloves-checkbox-2"></div><input type="checkbox" id="checkbox-2" name="checkbox-2" data-name="Checkbox 2" required="" style="opacity:0;position:absolute;z-index:-1"><span class="gloves-checkbox-2-label w-form-label" for="checkbox-2">6 1/2</span>
                </label></form>
              <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
              </div>
              <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
              </div>
            </div>
            <div class="w-layout-hflex closing-needles">
              <a href="#" class="gloves-edit-window-add-button w-button"><svg class="up-arrow" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-dc8cj" fill-rule="evenodd" clip-rule="evenodd" d="M16.5303 14.0303C16.2374 14.3232 15.7626 14.3232 15.4697 14.0303L12 10.5607L8.53033 14.0303C8.23744 14.3232 7.76256 14.3232 7.46967 14.0303C7.17678 13.7374 7.17678 13.2626 7.46967 12.9697L11.4697 8.96967C11.7626 8.67678 12.2374 8.67678 12.5303 8.96967L16.5303 12.9697C16.8232 13.2626 16.8232 13.7374 16.5303 14.0303Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
              <div class="w-form">
                <form id="email-form-2" name="email-form-2" data-name="Email Form 2" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="fa1a3e14-f127-7457-af43-31dc303b52c5"><input class="text-field-3 w-input" maxlength="256" name="field-2" data-name="Field 2" placeholder="Example Text" type="text" id="field-2" required=""></form>
                <div class="w-form-done">
                  <div>Thank you! Your submission has been received!</div>
                </div>
                <div class="w-form-fail">
                  <div>Oops! Something went wrong while submitting the form.</div>
                </div>
              </div>
              <a href="#" class="gloves-edit-window-add-button w-button"><svg class="down-arrow" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-sqcs" fill-rule="evenodd" clip-rule="evenodd" d="M16.5303 8.96967C16.8232 9.26256 16.8232 9.73744 16.5303 10.0303L12.5303 14.0303C12.2374 14.3232 11.7626 14.3232 11.4697 14.0303L7.46967 10.0303C7.17678 9.73744 7.17678 9.26256 7.46967 8.96967C7.76256 8.67678 8.23744 8.67678 8.53033 8.96967L12 12.4393L15.4697 8.96967C15.7626 8.67678 16.2374 8.67678 16.5303 8.96967Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
            </div>
          </div>
          <div class="w-layout-hflex">
            <div class="w-form">
              <form id="email-form" name="email-form" data-name="Email Form" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="32d8ef25-8639-8774-9579-17d65c66fe87"><label class="w-checkbox piat-item-1">
                  <div class="w-checkbox-input w-checkbox-input--inputType-custom gloves-checkbox-2"></div><input type="checkbox" id="checkbox-2" name="checkbox-2" data-name="Checkbox 2" required="" style="opacity:0;position:absolute;z-index:-1"><span class="gloves-checkbox-2-label w-form-label" for="checkbox-2">6 1/2</span>
                </label></form>
              <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
              </div>
              <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
              </div>
            </div>
            <div class="w-layout-hflex closing-needles">
              <a href="#" class="gloves-edit-window-add-button w-button"><svg class="up-arrow" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-dc8cj" fill-rule="evenodd" clip-rule="evenodd" d="M16.5303 14.0303C16.2374 14.3232 15.7626 14.3232 15.4697 14.0303L12 10.5607L8.53033 14.0303C8.23744 14.3232 7.76256 14.3232 7.46967 14.0303C7.17678 13.7374 7.17678 13.2626 7.46967 12.9697L11.4697 8.96967C11.7626 8.67678 12.2374 8.67678 12.5303 8.96967L16.5303 12.9697C16.8232 13.2626 16.8232 13.7374 16.5303 14.0303Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
              <div class="w-form">
                <form id="email-form-2" name="email-form-2" data-name="Email Form 2" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="32d8ef25-8639-8774-9579-17d65c66fe97"><input class="text-field-3 w-input" maxlength="256" name="field-2" data-name="Field 2" placeholder="Example Text" type="text" id="field-2" required=""></form>
                <div class="w-form-done">
                  <div>Thank you! Your submission has been received!</div>
                </div>
                <div class="w-form-fail">
                  <div>Oops! Something went wrong while submitting the form.</div>
                </div>
              </div>
              <a href="#" class="gloves-edit-window-add-button w-button"><svg class="down-arrow" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-sqcs" fill-rule="evenodd" clip-rule="evenodd" d="M16.5303 8.96967C16.8232 9.26256 16.8232 9.73744 16.5303 10.0303L12.5303 14.0303C12.2374 14.3232 11.7626 14.3232 11.4697 14.0303L7.46967 10.0303C7.17678 9.73744 7.17678 9.26256 7.46967 8.96967C7.76256 8.67678 8.23744 8.67678 8.53033 8.96967L12 12.4393L15.4697 8.96967C15.7626 8.67678 16.2374 8.67678 16.5303 8.96967Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
            </div>
          </div>
          <div class="w-layout-hflex">
            <div class="w-form">
              <form id="email-form" name="email-form" data-name="Email Form" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="371e46eb-b32d-1de4-57bf-9d1e19748a16"><label class="w-checkbox piat-item-1">
                  <div class="w-checkbox-input w-checkbox-input--inputType-custom gloves-checkbox-2"></div><input type="checkbox" id="checkbox-2" name="checkbox-2" data-name="Checkbox 2" required="" style="opacity:0;position:absolute;z-index:-1"><span class="gloves-checkbox-2-label w-form-label" for="checkbox-2">6 1/2</span>
                </label></form>
              <div class="w-form-done">
                <div>Thank you! Your submission has been received!</div>
              </div>
              <div class="w-form-fail">
                <div>Oops! Something went wrong while submitting the form.</div>
              </div>
            </div>
            <div class="w-layout-hflex closing-needles">
              <a href="#" class="gloves-edit-window-add-button w-button"><svg class="up-arrow" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-dc8cj" fill-rule="evenodd" clip-rule="evenodd" d="M16.5303 14.0303C16.2374 14.3232 15.7626 14.3232 15.4697 14.0303L12 10.5607L8.53033 14.0303C8.23744 14.3232 7.76256 14.3232 7.46967 14.0303C7.17678 13.7374 7.17678 13.2626 7.46967 12.9697L11.4697 8.96967C11.7626 8.67678 12.2374 8.67678 12.5303 8.96967L16.5303 12.9697C16.8232 13.2626 16.8232 13.7374 16.5303 14.0303Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
              <div class="w-form">
                <form id="email-form-2" name="email-form-2" data-name="Email Form 2" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="371e46eb-b32d-1de4-57bf-9d1e19748a26"><input class="text-field-3 w-input" maxlength="256" name="field-2" data-name="Field 2" placeholder="Example Text" type="text" id="field-2" required=""></form>
                <div class="w-form-done">
                  <div>Thank you! Your submission has been received!</div>
                </div>
                <div class="w-form-fail">
                  <div>Oops! Something went wrong while submitting the form.</div>
                </div>
              </div>
              <a href="#" class="gloves-edit-window-add-button w-button"><svg class="down-arrow" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-sqcs" fill-rule="evenodd" clip-rule="evenodd" d="M16.5303 8.96967C16.8232 9.26256 16.8232 9.73744 16.5303 10.0303L12.5303 14.0303C12.2374 14.3232 11.7626 14.3232 11.4697 14.0303L7.46967 10.0303C7.17678 9.73744 7.17678 9.26256 7.46967 8.96967C7.76256 8.67678 8.23744 8.67678 8.53033 8.96967L12 12.4393L15.4697 8.96967C15.7626 8.67678 16.2374 8.67678 16.5303 8.96967Z" fill="currentColor" app="ikonik"></path>
                </svg></a>
            </div>
          </div>
          <a data-w-id="9ec6a367-6447-7725-9004-3b8dbc4b0d44" href="#" class="gloves-edit-window-update-button w-button">Update</a>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar-no-shadow">
    <div data-animation="default" data-collapse="none" data-duration="400" data-easing="ease" data-easing2="ease" role="banner" class="navbar-no-shadow-container w-nav">
      <div class="container-regular">
        <div class="navbar-wrapper">
          <h1 class="heading-3">MedTrack</h1>
          <div class="w-layout-blockcontainer container-13 w-container"></div>
          <nav role="navigation" class="nav-menu-wrapper w-nav-menu">
            <ul role="list" class="nav-menu w-list-unstyled">
              <li><svg class="dashboard" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <defs app="ikonik">
                    <clippath app="ikonik">
                      <rect class="rect-48iy9j" width="24" height="24" fill="currentColor" app="ikonik"></rect>
                    </clippath>
                  </defs>
                  <g clip-path="url(#clip0_6_12259)" app="ikonik">
                    <path class="path-743sq" d="M3 13H11V3H3V13ZM3 21H11V15H3V21ZM13 21H21V11H13V21ZM13 3V9H21V3H13Z" fill="currentColor" app="ikonik"></path>
                  </g>
                </svg></li>
              <li class="list-item"><svg class="chart" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24" width="35" height="35" fill="currentColor" app="ikonik">
                  <path d="M20 2C20.5523 2 21 2.44772 21 3V21C21 21.5523 20.5523 22 20 22H6C5.44772 22 5 21.5523 5 21V19H3V17H5V15H3V13H5V11H3V9H5V7H3V5H5V3C5 2.44772 5.44772 2 6 2H20ZM14 8H12V11H9V13H11.999L12 16H14L13.999 13H17V11H14V8Z" app="ikonik"></path>
                </svg></li>
              <li class="list-item-2"><svg class="notifications" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                  <path class="path-h7pkx" fill-rule="evenodd" clip-rule="evenodd" d="M13 3C13 2.44772 12.5523 2 12 2C11.4477 2 11 2.44772 11 3V3.75H10.4426C8.21751 3.75 6.37591 5.48001 6.23702 7.70074L6.01601 11.2342C5.93175 12.5814 5.47946 13.8797 4.7084 14.9876C4.01172 15.9886 4.63194 17.3712 5.84287 17.5165L9.25 17.9254V19C9.25 20.5188 10.4812 21.75 12 21.75C13.5188 21.75 14.75 20.5188 14.75 19V17.9254L18.1571 17.5165C19.3681 17.3712 19.9883 15.9886 19.2916 14.9876C18.5205 13.8797 18.0682 12.5814 17.984 11.2342L17.763 7.70074C17.6241 5.48001 15.7825 3.75 13.5574 3.75H13V3ZM10.75 19C10.75 19.6904 11.3096 20.25 12 20.25C12.6904 20.25 13.25 19.6904 13.25 19V18.25H10.75V19Z" fill="currentColor" app="ikonik"></path>
                </svg></li>
              <li class="list-item-3"><svg class="settings" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 1024 1024" app="ikonik">
                  <path class="path-y6hhh" fill="currentColor" d="M512.5 390.6c-29.9 0-57.9 11.6-79.1 32.8-21.1 21.2-32.8 49.2-32.8 79.1 0 29.9 11.7 57.9 32.8 79.1 21.2 21.1 49.2 32.8 79.1 32.8 29.9 0 57.9-11.7 79.1-32.8 21.1-21.2 32.8-49.2 32.8-79.1 0-29.9-11.7-57.9-32.8-79.1a110.96 110.96 0 0 0-79.1-32.8zm412.3 235.5l-65.4-55.9c3.1-19 4.7-38.4 4.7-57.7s-1.6-38.8-4.7-57.7l65.4-55.9a32.03 32.03 0 0 0 9.3-35.2l-.9-2.6a442.5 442.5 0 0 0-79.6-137.7l-1.8-2.1a32.12 32.12 0 0 0-35.1-9.5l-81.2 28.9c-30-24.6-63.4-44-99.6-57.5l-15.7-84.9a32.05 32.05 0 0 0-25.8-25.7l-2.7-.5c-52-9.4-106.8-9.4-158.8 0l-2.7.5a32.05 32.05 0 0 0-25.8 25.7l-15.8 85.3a353.44 353.44 0 0 0-98.9 57.3l-81.8-29.1a32 32 0 0 0-35.1 9.5l-1.8 2.1a445.93 445.93 0 0 0-79.6 137.7l-.9 2.6c-4.5 12.5-.8 26.5 9.3 35.2l66.2 56.5c-3.1 18.8-4.6 38-4.6 57 0 19.2 1.5 38.4 4.6 57l-66 56.5a32.03 32.03 0 0 0-9.3 35.2l.9 2.6c18.1 50.3 44.8 96.8 79.6 137.7l1.8 2.1a32.12 32.12 0 0 0 35.1 9.5l81.8-29.1c29.8 24.5 63 43.9 98.9 57.3l15.8 85.3a32.05 32.05 0 0 0 25.8 25.7l2.7.5a448.27 448.27 0 0 0 158.8 0l2.7-.5a32.05 32.05 0 0 0 25.8-25.7l15.7-84.9c36.2-13.6 69.6-32.9 99.6-57.5l81.2 28.9a32 32 0 0 0 35.1-9.5l1.8-2.1c34.8-41.1 61.5-87.4 79.6-137.7l.9-2.6c4.3-12.4.6-26.3-9.5-35zm-412.3 52.2c-97.1 0-175.8-78.7-175.8-175.8s78.7-175.8 175.8-175.8 175.8 78.7 175.8 175.8-78.7 175.8-175.8 175.8z" app="ikonik"></path>
                </svg></li>
              <li class="mobile-margin-top-11">
                <div class="nav-button-wrapper"><svg class="profile" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 24 24" fill="none" app="ikonik">
                    <path class="path-gqeuc" fill-rule="evenodd" clip-rule="evenodd" d="M12 4C7.58172 4 4 7.58172 4 12C4 13.4369 4.37801 14.7832 5.0399 15.9474C5.95387 14.7632 7.38713 14 8.99998 14H15C16.6128 14 18.0461 14.7632 18.9601 15.9475C19.622 14.7833 20 13.4369 20 12C20 7.58172 16.4183 4 12 4ZM19.9429 18.0761C20.0682 17.9125 20.1886 17.745 20.3038 17.5737C21.3749 15.9807 22 14.0618 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 14.0618 2.62509 15.9807 3.69625 17.5737C3.81141 17.745 3.93174 17.9125 4.05702 18.076L4.05179 18.0936L4.4068 18.5074C6.23929 20.6439 8.9618 22 12 22C12 22 12 22 12 22C12.2163 22 12.431 21.9931 12.6438 21.9796C14.5055 21.8613 16.2285 21.2333 17.6751 20.2346C18.3869 19.7431 19.0318 19.1619 19.5932 18.5074L19.9482 18.0936L19.9429 18.0761ZM12 6C10.3431 6 9 7.34315 9 9C9 10.6569 10.3431 12 12 12C13.6569 12 15 10.6569 15 9C15 7.34315 13.6569 6 12 6Z" fill="currentColor" app="ikonik"></path>
                  </svg></div>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </div>
  <section>
    <div class="w-layout-hflex">
      <div class="w-layout-blockcontainer container-14 w-container">
        <div class="w-layout-hflex flex-block-4">
          <div class="w-layout-blockcontainer procedure-info-container w-container">
            <div class="procedure-info-surgeon">Surgeon:<?php if (isset($_SESSION['surgeon'])) echo "Dr. ".$_SESSION['surgeon'];?></div>
            <div class="procedure-info-procedure">Procedure:<?php if (isset($_SESSION['procedure'])) echo $_SESSION['procedure']. " Surgery";?></div>
            <div class="procdure-info-patient-name">Patient Name:</div>
          </div>
          <div class="w-layout-blockcontainer logistics-container w-container">
            <div class="logistics-location">Location:</div>
            <div class="logistics-antitipated-start-time">Anticipated Start Time:</div>
            <div class="logistics-date">Date:</div>
          </div>
        </div>
      </div>
      <div class="w-layout-blockcontainer patient-position-container w-container">
        <div class="patient-position-title">Patient Position</div>
        <div class="patient-position-text">details of the positioning of the patient go here</div>
      </div>
      <div class="w-layout-blockcontainer skin-prep-container w-container">
        <div class="skin-prep-title">Skin Prep</div>
        <div class="skin-prep-text">details of the skin prep of th patient go here</div>
      </div>
    </div>
  </section>
  <section class="section-12">
    <div class="w-layout-hflex">
      <div class="w-layout-blockcontainer gloves w-container">
        <div class="w-layout-hflex gloves-top-bar">
          <div class="gloves-title">Gloves</div>
          <div class="gloveds-qty">QTY</div>
          <a data-w-id="13b80800-7929-2d6b-2f0b-94b4f21c44df" href="#" class="gloves-edit-button w-button"><svg class="edit-icon" xmlns="http://www.w3.org/2000/svg" width="35" height="35" viewbox="0 0 1024 1024" app="ikonik">
              <path class="path-sidr8" fill="currentColor" d="M880 836H144c-17.7 0-32 14.3-32 32v36c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-36c0-17.7-14.3-32-32-32zm-622.3-84c2 0 4-.2 6-.5L431.9 722c2-.4 3.9-1.3 5.3-2.8l423.9-423.9a9.96 9.96 0 0 0 0-14.1L694.9 114.9c-1.9-1.9-4.4-2.9-7.1-2.9s-5.2 1-7.1 2.9L256.8 538.8c-1.5 1.5-2.4 3.3-2.8 5.3l-29.5 168.2a33.5 33.5 0 0 0 9.4 29.8c6.6 6.4 14.9 9.9 23.8 9.9z" app="ikonik"></path>
            </svg></a>
        </div>
        <div class="w-layout-hflex">
          <div class="w-form">
            <form id="email-form" name="email-form" data-name="Email Form" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="76b689e5-3d5d-1048-2074-91da8d99e704"><label class="w-checkbox piat-item-1">
                <div class="w-checkbox-input w-checkbox-input--inputType-custom gloves-checkbox-2"></div><input type="checkbox" id="<?php echo $val['tool_type'] ?>" onclick = "BoxVal('Needle'); ToolCheck(<?php echo $val['tool_type'] ?>) " name="Needle" data-name="Checkbox" required="" style="opacity:0;position:absolute;z-index:-1"><span class="gloves-checkbox-2-label w-form-label" for="checkbox"><?php echo $val['tool_type'] ?></span>
                <script>
                   function BoxVal(checkboxname) {
                    let checkboxes =  document.getElementsByName(checkboxname); //Get the general list of checkbox names
                    let checked = 0;
                    let notchecked = 0;
                    for (var i = 0; i < checkboxes.length; i++) {
                        if (checkboxes[i].checked) {
                            checked += 1;
                        }
                    }
                    if (checked == 3 && notchecked == 0){ // if all the checkboxes in a group are clicked
                      //record that all are checked
                      var xmlhttp = new XMLHttpRequest();
                      xmlhttp.open("GET", "postimeout.php?q=", true);
                      xmlhttp.send();
                      document.getElementById("return check").innerHTML = "All good";
                      checked = 0;
                    }
                    else{
                      checked = 0;
                      document.getElementById("return check").innerHTML = ""
                    }
                    }

                    function ToolCheck(checkboxid){
                      let checkbox =  document.getElementById(checkboxid); //Get the tool id from the associated checkbox
                      var xmlhttp = new XMLHttpRequest();
                      let isChecked = checkbox.checked;
                      var params = "id=" + encodeURIComponent(checkbox.id) + "&isChecked=" + isChecked;
                      var url = "updateTool.php";
                      xmlhttp.open("GET", url + "?" + params, true);

                          // Set the onload function to handle the response
                      xmlhttp.onload = function() {
                          if (xmlhttp.status >= 200 && xmlhttp.status < 400) {
                              // Request was successful
                              var response = xmlhttp.responseText;
                              console.log(response); // Log the response
                          } else {
                              // Error handling
                              console.error("Error: " + xmlhttp.statusText);
                          }
                      };
                      xmlhttp.send();
                    }

                    function selectAllTools(checkboxname){
                      let checkboxes =  document.getElementById(checkboxid); //Get the tool id from the associated checkbox
                      for (var i = 0; i < checkboxes.length; i++) {
                        checkboxes[i].checked = true;
                        ToolCheck(checkboxes[i].id);
                    }
                    }
                    </script>
              </label></form>
              <p> Response: <span id="return check"></span></p>
            <div class="w-form-done">
              <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
              <div>Oops! Something went wrong while submitting the form.</div>
            </div>
          </div>
          <div class="text-block-17"><?php echo $val['tool_amount']?></div>
        </div>
        <div class="w-layout-hflex">
          <div class="w-form">
            <form id="email-form" name="email-form" data-name="Email Form" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="df322d20-dd2d-3160-2d97-83c0b556810f"><label class="w-checkbox piat-item-1">
                <div class="w-checkbox-input w-checkbox-input--inputType-custom gloves-checkbox-2"></div><input type="checkbox" id="3-0 Needle" onclick = "BoxVal('Needle')" name="Needle" data-name="Checkbox 2" required="" style="opacity:0;position:absolute;z-index:-1"><span class="gloves-checkbox-2-label-copy w-form-label" for="checkbox-2">3-0 Needle</span>
              </label></form>
            <div class="w-form-done">
              <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
              <div>Oops! Something went wrong while submitting the form.</div>
            </div>
          </div>
        </div>
        <div class="w-layout-hflex">
          <div class="w-form">
            <form id="email-form" name="email-form" data-name="Email Form" method="get" data-wf-page-id="662ff875402765eb893847f8" data-wf-element-id="a978c414-db3d-adf1-0ff3-307fc18f67e5"><label class="w-checkbox piat-item-1">
                <div class="w-checkbox-input w-checkbox-input--inputType-custom gloves-checkbox-3"></div><input type="checkbox" id="4-0 Needle" onclick = "BoxVal('Needle')" name="Needle" data-name="Checkbox 2" required="" style="opacity:0;position:absolute;z-index:-1"><span class="gloves-checkbox-2-label w-form-label" for="checkbox-2">4-0 Needle</span>
              </label></form>
            <div class="w-form-done">
              <div>Thank you! Your submission has been received!</div>
            </div>
            <div class="w-form-fail">
              <div>Oops! Something went wrong while submitting the form.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section>
    <div class="w-layout-hflex">
      <a href="#" class="save-button w-button">SAVE</a>
      <a href="timeout-1.php" class="next-button w-button">Pre-Anesthesia  Time Out →</a>
    </div>
  </section>
  <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=6629b58137d7c761e37bacd0" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  <script src="jeyan_v0/whiteboard-gui-v0/js/webflow.js" type="text/javascript"></script>
</body>
</html>