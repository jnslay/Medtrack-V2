<?php
$con = mysqli_connect("localhost","root","","test");
$ret = "UPDATE `tools` SET `Needles`='3' WHERE 1";
$result = mysqli_query($con,$ret);
?>
