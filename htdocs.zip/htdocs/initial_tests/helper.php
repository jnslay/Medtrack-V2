<?php
session_start();
$con = mysqli_connect("localhost","root","","test");

if(isset($_POST['sub_needle'])){
    $ret = "SELECT * FROM `surgical tools` WHERE 1";
    $result = ($con->query($ret));
    $value = 0;
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $value = $row["Needles"] - 1;
    }
    if ($value < 0){
        $value = 0;
    }
    $query  = "UPDATE `surgical tools` SET `Needles`='$value',`Sponges`='$value' WHERE 1";
    $query_run = mysqli_query($con, $query);
    $_SESSION['needle_val'] =  $value;
    header("Location: testing1.php");
    }

} elseif (isset($_POST['add_needle'])) {
    $ret = "SELECT * FROM `surgical tools` WHERE 1";
    $result = ($con->query($ret));
    $value = 0;
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            #echo " - Name: " . $row["Needles"]. " " . $row["Sponges"]. "<br>";
            $value = $row["Needles"] + 1;
        }
    $query  = "UPDATE `surgical tools` SET `Needles`='$value',`Sponges`='$value' WHERE 1";
    $query_run = mysqli_query($con, $query);
    $_SESSION['needle_val'] =  $value;
    header("Location: testing1.php");
}
}