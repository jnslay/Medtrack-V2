<?php session_start(); ?>

<html lang=“en”>
<head>
    <meta charset=“UTF-8">
    <meta name=“viewport” content=“width=device-width, initial-scale=1.0">
    <title>Button Example</title>
</head>
<body>
    <!-- Button with text content -->
    <h?> Needles <h><br>
    <form method="POST" action = "helper.php">
        <button type = "submit" name = "sub_needle">-</button>
    </form>
    <!-- Button with an image -->
    <form method="POST" action = "helper.php">
        <button type = "submit" name = "add_needle">+</button>
    </form>

    
<?php
if (isset($_SESSION['needle_val'])) {
?>
    <br><br><h?><u>Needles</u><h>
    <p> <?php echo $_SESSION['needle_val']?> </p>
    <?php unset($_SESSION['needle_val']) ?>

<?php
} else {
    echo "<p>";
    echo "<h?><u>Needles</u><h><br>";
    echo "0";
    echo "</p>";
}
?>

</body>
</html>