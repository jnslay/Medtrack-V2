<?php
// Check if the 'id' and 'isChecked' parameters are set in the GET request
if (isset($_GET['id']) && isset($_GET['isChecked'])) {
    // Get the values of 'id' and 'isChecked' parameters
    $id = $_GET['id'];
    $isChecked = $_GET['isChecked'];

    // Assuming you have a database connection established
    // Replace the database connection details with your own
    $servername = "localhost";
    $username = "your_username";
    $password = "your_password";
    $dbname = "your_database";

    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "test");

    // Check if the connection was successful
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SQL query to update the tool's status based on the checkbox state
    
    $sql = "UPDATE tools SET status = '$isChecked' WHERE id = '$id'"; //update with Jeyan's new database!

    if ($conn->query($sql) === TRUE) {
        // Return a success message
        echo "Record updated successfully";
    } else {
        // Return an error message if the query fails
        echo "Error updating record: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    // Return an error message if 'id' or 'isChecked' parameters are missing
    echo "Error: 'id' and 'isChecked' parameters are required";
}
?>
