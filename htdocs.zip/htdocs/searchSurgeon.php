<?php
session_start();
$con = mysqli_connect("localhost","root","","test");
$success = false;

if(isset($_POST['surgeonQuery'])){
    $name = $_POST['surgeonQuery'];
    #echo $_POST['surgeonQuery'];
    $ret = "SELECT * FROM `surgeons` WHERE 1";
    $result = ($con->query($ret));
    $val = 0;
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            #echo $row['surgeon'];
            #echo $name;
            if ($row['surgeon'] == $name){
                #echo "here";
                $success = true;
                $val = $row;
            }
        }
    }

    if ($success){
        #echo "success";
        $_SESSION['searchBool'] = true;
        $_SESSION['surgeon'] = $val['surgeon'];
        $_SESSION['procedure'] = $val['procedure'];
        header("Location: pref-card-search.php");

    }
    else {
        #echo "fail";
        $_SESSION['searchBool'] = false;
        header("Location: pref-card-search.php");
    }
}
else{
    echo "<h1> Not Working M8 </h1>";
}